import tkinter as tk
from tkinter import ttk, messagebox
import os
import csv
from datetime import date, datetime
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
from collections import defaultdict

ARQUIVO = "transacoes.csv"

CATEGORIAS_ENTRADA = ["Salário", "Freelance", "Investimentos", "Vendas", "Outros"]
CATEGORIAS_SAIDA = ["Alimentação", "Transporte", "Moradia", "Lazer", "Saúde", "Educação", "Assinaturas", "Outros"]

# ===== FUNÇÕES AUXILIARES =====

def centralizar_janela(janela, largura, altura):
    tela_largura = janela.winfo_screenwidth()
    tela_altura = janela.winfo_screenheight()
    x = (tela_largura - largura) // 2
    y = (tela_altura - altura) // 2 
    janela.geometry(f"{largura}x{altura}+{x}+{y}")

def salvar_transacao(tipo, descricao, valor, categoria, data_transacao):
    arquivo_existe = os.path.exists(ARQUIVO)
    
    with open(ARQUIVO, "a", newline="", encoding="utf-8") as f:
        campos = ["tipo", "descricao", "valor", "data", "categoria"]
        escritor = csv.DictWriter(f, fieldnames=campos)
        
        if not arquivo_existe:
            escritor.writeheader()
        
        escritor.writerow({
            "tipo": tipo,
            "descricao": descricao,
            "valor": valor,
            "data": data_transacao,
            "categoria": categoria
        })

def carregar_dados():
    """Carrega todas as transações do arquivo CSV"""
    dados = []
    if os.path.exists(ARQUIVO):
        with open(ARQUIVO, "r", encoding="utf-8") as f:
            leitor = csv.DictReader(f)
            for linha in leitor:
                linha['valor'] = float(linha['valor'])
                dados.append(linha)
    return dados

def obter_resumo(dados, data_inicio=None, data_fim=None, tipo_filtro="Todos"):
    """Filtra e calcula resumo dos dados"""
    resumo = {
        'total_entradas': 0,
        'total_saidas': 0,
        'saldo': 0,
        'entradas_por_categoria': defaultdict(float),
        'saidas_por_categoria': defaultdict(float),
        'transacoes_por_data': defaultdict(lambda: {'entrada': 0, 'saida': 0}),
        'saldo_acumulado': [],
        'datas': [],
        'qtd_transacoes': 0
    }
    
    dados_filtrados = []
    
    for item in dados:
        # Converte a data da transação
        try:
            data_item = datetime.strptime(item['data'], "%d/%m/%Y")
        except:
            continue
        
        # Filtra por data
        if data_inicio and data_item.date() < data_inicio:
            continue
        if data_fim and data_item.date() > data_fim:
            continue
        
        # Filtra por tipo
        if tipo_filtro == "Entradas" and item['tipo'] != 'entrada':
            continue
        if tipo_filtro == "Saídas" and item['tipo'] != 'saida':
            continue
        
        dados_filtrados.append(item)
    
    # Ordena por data
    dados_filtrados.sort(key=lambda x: datetime.strptime(x['data'], "%d/%m/%Y"))
    
    saldo_acum = 0
    
    for item in dados_filtrados:
        if item['tipo'] == 'entrada':
            resumo['total_entradas'] += item['valor']
            resumo['entradas_por_categoria'][item.get('categoria', 'Outros')] += item['valor']
            resumo['transacoes_por_data'][item['data']]['entrada'] += item['valor']
            saldo_acum += item['valor']
        else:
            resumo['total_saidas'] += item['valor']
            resumo['saidas_por_categoria'][item.get('categoria', 'Outros')] += item['valor']
            resumo['transacoes_por_data'][item['data']]['saida'] += item['valor']
            saldo_acum -= item['valor']
        
        resumo['saldo_acumulado'].append(saldo_acum)
        resumo['datas'].append(item['data'])
    
    resumo['saldo'] = resumo['total_entradas'] - resumo['total_saidas']
    resumo['qtd_transacoes'] = len(dados_filtrados)
    
    return resumo

# ===== JANELA DE TRANSAÇÃO =====

def abrir_janela_transacao(tipo):
    janela_transacao = tk.Toplevel()
    titulo = "Adicionar Entrada 💵" if tipo == "entrada" else "Adicionar Saída 💸"
    cor = "#2ecc71" if tipo == "entrada" else "#e74c3c"
    
    janela_transacao.title(titulo)
    centralizar_janela(janela_transacao, 400, 400)
    janela_transacao.configure(bg="#2c3e50")
    janela_transacao.resizable(False, False)
    
    tk.Label(
        janela_transacao,
        text=titulo,
        font=("Arial", 18, "bold"),
        fg=cor,
        bg="#2c3e50"
    ).pack(pady=20)
    
    frame = tk.Frame(janela_transacao, bg="#2c3e50")
    frame.pack(pady=10, padx=30, fill="both")
    
    # Descrição
    tk.Label(frame, text="Descrição:", fg="white", bg="#2c3e50", font=("Arial", 11)).pack(anchor="w")
    entrada_descricao = tk.Entry(frame, font=("Arial", 11))
    entrada_descricao.pack(fill="x", pady=(5, 12))
    
    # Valor
    tk.Label(frame, text="Valor R$:", fg="white", bg="#2c3e50", font=("Arial", 11)).pack(anchor="w")
    entrada_valor = tk.Entry(frame, font=("Arial", 11))
    entrada_valor.pack(fill="x", pady=(5, 12))
    
    # Categoria
    tk.Label(frame, text="Categoria:", fg="white", bg="#2c3e50", font=("Arial", 11)).pack(anchor="w")
    categorias = CATEGORIAS_ENTRADA if tipo == "entrada" else CATEGORIAS_SAIDA
    combo_categoria = ttk.Combobox(frame, values=categorias, font=("Arial", 11), state="readonly")
    combo_categoria.set(categorias[0])
    combo_categoria.pack(fill="x", pady=(5, 12))
    
    # Data
    tk.Label(frame, text="Data:", fg="white", bg="#2c3e50", font=("Arial", 11)).pack(anchor="w")
    data_hoje = date.today().strftime("%d/%m/%Y")
    entrada_data = tk.Entry(frame, font=("Arial", 11))
    entrada_data.insert(0, data_hoje)
    entrada_data.pack(fill="x", pady=(5, 15))
    
    def salvar():
        descricao = entrada_descricao.get().strip()
        valor_str = entrada_valor.get().strip()
        categoria = combo_categoria.get()
        data_transacao = entrada_data.get().strip()
        
        if not descricao:
            messagebox.showerror("Erro", "Preencha a descrição!")
            return
        
        if not valor_str:
            messagebox.showerror("Erro", "Preencha o valor!")
            return
        
        try:
            valor = float(valor_str.replace(",", "."))
            if valor <= 0:
                messagebox.showerror("Erro", "O valor deve ser positivo!")
                return
        except ValueError:
            messagebox.showerror("Erro", "Valor inválido!")
            return
        
        salvar_transacao(tipo, descricao, valor, categoria, data_transacao)
        messagebox.showinfo("Sucesso!", f"{'Entrada' if tipo == 'entrada' else 'Saída'} adicionada!")
        janela_transacao.destroy()
    
    btn_salvar = tk.Button(
        frame, text="💾 Salvar", command=salvar,
        font=("Arial", 13, "bold"), bg=cor, fg="white",
        activebackground="#27ae60", cursor="hand2", relief="flat", height=1
    )
    btn_salvar.pack(fill="x", pady=(10, 0))

# ===== JANELA DO DASHBOARD =====

def abrir_dashboard():
    """Abre o dashboard integrado em uma nova janela"""
    dados = carregar_dados()
    
    if not dados:
        messagebox.showinfo("Aviso", "Nenhuma transação encontrada!\nAdicione entradas ou saídas primeiro.")
        return
    
    janela_dash = tk.Toplevel()
    janela_dash.title("📊 Dashboard Financeiro")
    janela_dash.state('zoomed')  # Maximizado
    janela_dash.configure(bg="#ecf0f1")
    
    # ===== FRAME SUPERIOR - CARDS =====
    frame_cards = tk.Frame(janela_dash, bg="#2c3e50", height=120)
    frame_cards.pack(fill="x", padx=10, pady=10)
    frame_cards.pack_propagate(False)
    
    # Variáveis dos cards
    var_total_entradas = tk.StringVar(value="R$ 0,00")
    var_total_saidas = tk.StringVar(value="R$ 0,00")
    var_saldo = tk.StringVar(value="R$ 0,00")
    var_qtd = tk.StringVar(value="0")
    
    # Função para atualizar cards e gráficos
    def atualizar_dashboard(*args):
        # Pega as datas dos filtros
        data_inicio_str = entry_data_inicio.get().strip()
        data_fim_str = entry_data_fim.get().strip()
        tipo_filtro = combo_tipo.get()
        
        try:
            data_inicio = datetime.strptime(data_inicio_str, "%d/%m/%Y").date() if data_inicio_str else None
        except:
            data_inicio = None
        try:
            data_fim = datetime.strptime(data_fim_str, "%d/%m/%Y").date() if data_fim_str else None
        except:
            data_fim = None
        
        resumo = obter_resumo(dados, data_inicio, data_fim, tipo_filtro)
        
        # Atualiza cards
        var_total_entradas.set(f"R$ {resumo['total_entradas']:,.2f}")
        var_total_saidas.set(f"R$ {resumo['total_saidas']:,.2f}")
        var_saldo.set(f"R$ {resumo['saldo']:,.2f}")
        var_qtd.set(str(resumo['qtd_transacoes']))
        
        # Cores dos cards
        cor_saldo = "#2ecc71" if resumo['saldo'] >= 0 else "#e74c3c"
        lbl_saldo.config(fg=cor_saldo)
        
        # Atualiza gráficos
        for widget in frame_graficos.winfo_children():
            widget.destroy()
        
        fig = Figure(figsize=(10, 6), facecolor="#ecf0f1")
        
        # Gráfico 1 - Pizza Entradas
        ax1 = fig.add_subplot(221)
        if resumo['entradas_por_categoria']:
            cats = list(resumo['entradas_por_categoria'].keys())
            vals = list(resumo['entradas_por_categoria'].values())
            ax1.pie(vals, labels=cats, autopct='%1.1f%%', startangle=90, 
                   colors=['#2ecc71', '#27ae60', '#1abc9c', '#16a085', '#2ecc71'])
            ax1.set_title('Entradas por Categoria', fontweight='bold', fontsize=11)
        else:
            ax1.text(0.5, 0.5, 'Sem dados', ha='center', va='center', fontsize=12)
            ax1.set_title('Entradas por Categoria', fontweight='bold')
        
        # Gráfico 2 - Pizza Saídas
        ax2 = fig.add_subplot(222)
        if resumo['saidas_por_categoria']:
            cats = list(resumo['saidas_por_categoria'].keys())
            vals = list(resumo['saidas_por_categoria'].values())
            ax2.pie(vals, labels=cats, autopct='%1.1f%%', startangle=90,
                   colors=['#e74c3c', '#c0392b', '#f39c12', '#e67e22', '#d35400', '#ff6b6b', '#ee5a24', '#ff4757'])
            ax2.set_title('Saídas por Categoria', fontweight='bold', fontsize=11)
        else:
            ax2.text(0.5, 0.5, 'Sem dados', ha='center', va='center', fontsize=12)
            ax2.set_title('Saídas por Categoria', fontweight='bold')
        
        # Gráfico 3 - Barras Comparativo
        ax3 = fig.add_subplot(223)
        categorias_todas = list(set(list(resumo['entradas_por_categoria'].keys()) + 
                                   list(resumo['saidas_por_categoria'].keys())))
        if categorias_todas:
            entradas_vals = [resumo['entradas_por_categoria'][c] for c in categorias_todas]
            saidas_vals = [resumo['saidas_por_categoria'][c] for c in categorias_todas]
            x = range(len(categorias_todas))
            width = 0.35
            ax3.bar([i - width/2 for i in x], entradas_vals, width, label='Entradas', color='#2ecc71')
            ax3.bar([i + width/2 for i in x], saidas_vals, width, label='Saídas', color='#e74c3c')
            ax3.set_xticks(x)
            ax3.set_xticklabels(categorias_todas, rotation=45, ha='right', fontsize=8)
            ax3.set_title('Comparativo por Categoria', fontweight='bold')
            ax3.legend(fontsize=8)
        else:
            ax3.text(0.5, 0.5, 'Sem dados', ha='center', va='center')
            ax3.set_title('Comparativo por Categoria', fontweight='bold')
        
        # Gráfico 4 - Linha Saldo Acumulado
        ax4 = fig.add_subplot(224)
        if resumo['datas'] and resumo['saldo_acumulado']:
            ax4.plot(range(len(resumo['datas'])), resumo['saldo_acumulado'], 
                    color='#3498db', linewidth=2, marker='o', markersize=3)
            ax4.fill_between(range(len(resumo['datas'])), resumo['saldo_acumulado'], 
                           alpha=0.3, color='#3498db')
            ax4.set_title('Evolução do Saldo', fontweight='bold')
            ax4.set_xlabel('Transações')
            ax4.set_ylabel('Saldo (R$)')
            ax4.axhline(y=0, color='black', linestyle='-', linewidth=0.5)
            if len(resumo['datas']) > 6:
                ax4.set_xticks(range(0, len(resumo['datas']), len(resumo['datas'])//6))
        else:
            ax4.text(0.5, 0.5, 'Sem dados', ha='center', va='center')
            ax4.set_title('Evolução do Saldo', fontweight='bold')
        
        fig.tight_layout(pad=3)
        
        canvas = FigureCanvasTkAgg(fig, master=frame_graficos)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True)
        
        # Atualiza tabela
        for item in tree.get_children():
            tree.delete(item)
        
        dados_mostrar = dados
        # Aplica filtros na tabela também
        for item in dados_mostrar:
            try:
                data_item = datetime.strptime(item['data'], "%d/%m/%Y")
            except:
                continue
            
            if data_inicio and data_item.date() < data_inicio:
                continue
            if data_fim and data_item.date() > data_fim:
                continue
            if tipo_filtro == "Entradas" and item['tipo'] != 'entrada':
                continue
            if tipo_filtro == "Saídas" and item['tipo'] != 'saida':
                continue
            
            emoji = "💵" if item['tipo'] == 'entrada' else "💸"
            tree.insert("", "end", values=(
                item['data'],
                emoji,
                item.get('categoria', 'Outros'),
                item['descricao'],
                f"R$ {item['valor']:,.2f}"
            ))
    
    # Cards
    for i in range(4):
        frame_cards.columnconfigure(i, weight=1)
    
    fonte_card = ("Arial", 13, "bold")
    fonte_valor = ("Arial", 18, "bold")
    
    # Card 1
    f1 = tk.Frame(frame_cards, bg="#34495e")
    f1.grid(row=0, column=0, padx=10, pady=15, sticky="nsew")
    tk.Label(f1, text="💵 Entradas", font=fonte_card, fg="#2ecc71", bg="#34495e").pack(pady=(15,5))
    tk.Label(f1, textvariable=var_total_entradas, font=fonte_valor, fg="white", bg="#34495e").pack(pady=(0,15))
    
    # Card 2
    f2 = tk.Frame(frame_cards, bg="#34495e")
    f2.grid(row=0, column=1, padx=10, pady=15, sticky="nsew")
    tk.Label(f2, text="💸 Saídas", font=fonte_card, fg="#e74c3c", bg="#34495e").pack(pady=(15,5))
    tk.Label(f2, textvariable=var_total_saidas, font=fonte_valor, fg="white", bg="#34495e").pack(pady=(0,15))
    
    # Card 3
    f3 = tk.Frame(frame_cards, bg="#34495e")
    f3.grid(row=0, column=2, padx=10, pady=15, sticky="nsew")
    tk.Label(f3, text="🏦 Saldo", font=fonte_card, fg="#3498db", bg="#34495e").pack(pady=(15,5))
    lbl_saldo = tk.Label(f3, textvariable=var_saldo, font=fonte_valor, fg="white", bg="#34495e")
    lbl_saldo.pack(pady=(0,15))
    
    # Card 4
    f4 = tk.Frame(frame_cards, bg="#34495e")
    f4.grid(row=0, column=3, padx=10, pady=15, sticky="nsew")
    tk.Label(f4, text="📌 Transações", font=fonte_card, fg="#f39c12", bg="#34495e").pack(pady=(15,5))
    tk.Label(f4, textvariable=var_qtd, font=fonte_valor, fg="white", bg="#34495e").pack(pady=(0,15))
    
    # ===== FRAME FILTROS =====
    frame_filtros = tk.Frame(janela_dash, bg="#ecf0f1")
    frame_filtros.pack(fill="x", padx=10, pady=5)
    
    tk.Label(frame_filtros, text="Data Início:", bg="#ecf0f1", font=("Arial", 10)).pack(side="left", padx=5)
    entry_data_inicio = tk.Entry(frame_filtros, width=12, font=("Arial", 10))
    entry_data_inicio.pack(side="left", padx=5)
    
    tk.Label(frame_filtros, text="Data Fim:", bg="#ecf0f1", font=("Arial", 10)).pack(side="left", padx=5)
    entry_data_fim = tk.Entry(frame_filtros, width=12, font=("Arial", 10))
    entry_data_fim.pack(side="left", padx=5)
    
    tk.Label(frame_filtros, text="Tipo:", bg="#ecf0f1", font=("Arial", 10)).pack(side="left", padx=5)
    combo_tipo = ttk.Combobox(frame_filtros, values=["Todos", "Entradas", "Saídas"], 
                              font=("Arial", 10), state="readonly", width=10)
    combo_tipo.set("Todos")
    combo_tipo.pack(side="left", padx=5)
    
    btn_filtrar = tk.Button(
        frame_filtros, text="🔍 Filtrar", command=atualizar_dashboard,
        font=("Arial", 10, "bold"), bg="#3498db", fg="white",
        cursor="hand2", relief="flat"
    )
    btn_filtrar.pack(side="left", padx=15)
    
    # Bind para filtrar ao pressionar Enter
    entry_data_inicio.bind("<Return>", atualizar_dashboard)
    entry_data_fim.bind("<Return>", atualizar_dashboard)
    combo_tipo.bind("<<ComboboxSelected>>", atualizar_dashboard)
    
    # ===== FRAME GRÁFICOS =====
    frame_graficos = tk.Frame(janela_dash, bg="white")
    frame_graficos.pack(fill="both", expand=True, padx=10, pady=5)
    
    # ===== TABELA =====
    frame_tabela = tk.Frame(janela_dash, bg="#ecf0f1", height=150)
    frame_tabela.pack(fill="x", padx=10, pady=5)
    
    colunas = ("Data", "Tipo", "Categoria", "Descrição", "Valor")
    tree = ttk.Treeview(frame_tabela, columns=colunas, show="headings", height=6)
    
    for col in colunas:
        tree.heading(col, text=col)
        tree.column(col, width=100)
    
    tree.column("Descrição", width=300)
    tree.column("Valor", width=120)
    
    scrollbar = ttk.Scrollbar(frame_tabela, orient="vertical", command=tree.yview)
    tree.configure(yscrollcommand=scrollbar.set)
    
    tree.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")
    
    # Carrega os dados iniciais
    atualizar_dashboard()

# ===== JANELA PRINCIPAL =====

janela_principal = tk.Tk()
janela_principal.title("Controle Financeiro")
centralizar_janela(janela_principal, 500, 450)
janela_principal.configure(bg="#2c3e50")
janela_principal.resizable(False, False)

# Título
tk.Label(
    janela_principal,
    text="💰 Controle Financeiro",
    font=("Arial", 24, "bold"),
    fg="white",
    bg="#2c3e50"
).pack(pady=30)

tk.Label(
    janela_principal,
    text="Gerencie suas finanças pessoais",
    font=("Arial", 11),
    fg="#bdc3c7",
    bg="#2c3e50"
).pack(pady=(0, 30))

# Frame dos botões
frame_botoes = tk.Frame(janela_principal, bg="#2c3e50")
frame_botoes.pack(expand=True)

# Estilo dos botões
estilo_botao = {
    "font": ("Arial", 13, "bold"),
    "fg": "white",
    "cursor": "hand2",
    "width": 25,
    "height": 2,
    "relief": "flat"
}

btn_entrada = tk.Button(
    frame_botoes,
    text="💵  Nova Entrada",
    command=lambda: abrir_janela_transacao("entrada"),
    bg="#2ecc71",
    activebackground="#27ae60",
    **estilo_botao
)
btn_entrada.pack(pady=8)

btn_saida = tk.Button(
    frame_botoes,
    text="💸  Nova Saída",
    command=lambda: abrir_janela_transacao("saida"),
    bg="#e74c3c",
    activebackground="#c0392b",
    **estilo_botao
)
btn_saida.pack(pady=8)

btn_dashboard = tk.Button(
    frame_botoes,
    text="📊  Dashboard",
    command=abrir_dashboard,
    bg="#3498db",
    activebackground="#2980b9",
    **estilo_botao
)
btn_dashboard.pack(pady=8)

btn_sair = tk.Button(
    janela_principal,
    text="❌  Sair",
    command=janela_principal.quit,
    font=("Arial", 12),
    bg="#7f8c8d",
    fg="white",
    activebackground="#95a5a6",
    cursor="hand2",
    width=12,
    relief="flat"
)
btn_sair.pack(side="bottom", pady=20)

tk.Label(
    janela_principal,
    text="v2.0 - Dashboard Integrado",
    font=("Arial", 7),
    fg="#7f8c8d",
    bg="#2c3e50"
).pack(side="bottom", pady=5)

janela_principal.mainloop()